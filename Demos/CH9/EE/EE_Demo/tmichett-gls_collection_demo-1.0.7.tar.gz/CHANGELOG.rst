*Change Log*

* March 26, 2024
** Added new demo role to collection
** Created Changelog file
